package com.example.repressales.model

class Order {
}