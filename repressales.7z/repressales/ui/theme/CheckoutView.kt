package com.example.repressales.ui.theme

class CheckoutView {
}